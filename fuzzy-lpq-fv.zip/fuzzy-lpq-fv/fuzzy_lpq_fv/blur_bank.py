"""
Section 6 — Blur degradation bank (Gaussian / motion / disk, matching
MATLAB's `fspecial`).

Used to build the blur-degraded test partitions of the evaluation
protocol.
"""

import numpy as np
from scipy.signal import fftconvolve


def fspecial_gaussian(hsize=7, sigma=1.0):
    r = hsize // 2
    ys = np.arange(-r, r + 1)
    Y1, Y2 = np.meshgrid(ys, ys, indexing="ij")
    h = np.exp(-(Y1 ** 2 + Y2 ** 2) / (2 * sigma ** 2))
    return h / h.sum()


def fspecial_disk(radius=3):
    r = int(np.ceil(radius))
    ys = np.arange(-r, r + 1)
    Y1, Y2 = np.meshgrid(ys, ys, indexing="ij")
    mask = (Y1 ** 2 + Y2 ** 2) <= radius ** 2
    h = mask.astype(np.float64)
    return h / h.sum()


def fspecial_motion(length=9, angle=0.0):
    length = max(int(round(length)), 1)
    theta = np.deg2rad(angle)
    half = (length - 1) / 2.0
    size = int(2 * np.ceil(half) + 1)
    h = np.zeros((size, size))
    center = size // 2
    for t in np.linspace(-half, half, max(length * 4, 2)):
        x = int(round(center + t * np.cos(theta)))
        y = int(round(center - t * np.sin(theta)))
        if 0 <= y < size and 0 <= x < size:
            h[y, x] = 1.0
    if h.sum() == 0:
        h[center, center] = 1.0
    return h / h.sum()


def apply_blur(image, kernel):
    return fftconvolve(image.astype(np.float64), kernel, mode="same")


BLUR_BANK = {
    "gaussian_s1": lambda: fspecial_gaussian(9, 1.0),
    "gaussian_s2": lambda: fspecial_gaussian(11, 2.0),
    "motion_l9_a30": lambda: fspecial_motion(9, 30),
    "motion_l13_a60": lambda: fspecial_motion(13, 60),
    "disk_r2": lambda: fspecial_disk(2),
    "disk_r3": lambda: fspecial_disk(3),
}
